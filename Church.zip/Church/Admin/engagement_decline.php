<?php
include("header.php");
include("config.php");
?>

<form action="approvel.php" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['_id']))
{
 $engagement_id=$_GET['_id'];
  $result=mysqli_query($con,"UPDATE tbl_engagement SET EngStatus='rejected' where EngId=$engagement_id");
  
}
if($result)
{
echo "<script>alert('Engagement details has been removed successfully. Thank you');window.location='approvel_engagement.php';</script>";
}
?>