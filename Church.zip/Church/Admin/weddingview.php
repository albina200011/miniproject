<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>

<form action="" method="post">
  <div class="container" style="width:100%;margin-left:13%;margin-bottom: 5%;" >
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
  
  </div>
  
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">WEDDING DETAILS</h2>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
  
  
   
     

   
   <?php

include("config.php");

if(isset($_GET["WeddId"]))

{
	
	$WeddId=$_GET["WeddId"];
	
	  
$sql=mysqli_query($con,"SELECT w.*,m1.MemberNm as Groom,m2.MemberNm as Bride,f.FamilyName as Famid FROM tbl_wedding w inner join tbl_member m1  on m1.MemberId=w.Groom inner join tbl_member m2 on m2.MemberId=w.Bride inner join tbl_family f on  f.FamilyId=w.Famid WHERE 	WeddId='$WeddId'");



   
    

   
   while($display=mysqli_fetch_array($sql))
   {
	echo "<tr>";

	echo "<td>Groom :</td>";
	echo "<td>".$display["Groom"]."</td>";

	echo "</tr>";
	echo "<tr>";
	echo "<td>Bride :</td>";
    echo "<td>".$display["Bride"]."</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>Family Name :</td>";
    echo "<td>".$display["Famid"]."</td>";
	echo "</tr>";
	
	echo "<tr>";
	echo "<td>Wedding Date :</td>";
    echo "<td>".$display["WDate"]."</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>Bride Parish  :</td>";
    echo "<td>".$display["BParish"]."</td>";
    echo "</tr>";
    echo "<tr>";
	echo "<td>Bride Diocese  :</td>";
    echo "<td>".$display["BDiocese"]."</td>";
    echo "</tr>";
    echo "<tr>";
	echo "<td>Bride Family Name  :</td>";
    echo "<td>".$display["BFamilyName"]."</td>";
    echo "</tr>";
    echo "<tr>";
	echo "<td>Priest  :</td>";
    echo "<td>".$display["WPriest"]."</td>";
    echo "</tr>";
    echo "<tr>";
	echo "<td>Church  :</td>";
    echo "<td>".$display["WChurch"]."</td>";
    echo "</tr>";
    echo "<tr>";
	echo "<td>Witness 1  :</td>";
    echo "<td>".$display["WW1"]."</td>";
    echo "</tr>";
   echo "<tr>";
	echo "<td>Witness 2  :</td>";
    echo "<td>".$display["WW2"]."</td>";
    echo "</tr>";
	
   }
   
}

echo "</table>";

?>

<div class="row">
    
   
     <input type="submit" name="btnsubmit" value="APPROVE" class="btn btn-primary" style="margin-left:5%; background-color:green;" /> 
    
      <input type="submit" name="submit" value="REJECT" class="btn btn-primary" style="margin-left:60%; background-color:red;" />
    </div>
   <br> 
    
  </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
if(isset($_POST["btnsubmit"]))
{
	mysqli_query($con, "UPDATE  tbl_wedding set WStatus='accepted' where WeddId=$WeddId");
	echo "<script>alert('Wedding Details Approved Successfully!!');window.location='viewwedding.php'</script>";
}
?>
<?php
if(isset($_POST["submit"]))
{
	mysqli_query($con, "UPDATE  tbl_wedding set WStatus='rejected' where WeddId=$WeddId");
	echo "<script>alert('Wedding Details Rejected Successfully!!');window.location='viewwedding.php'</script>";
}
?>
<?php
include("footer.php");
?>