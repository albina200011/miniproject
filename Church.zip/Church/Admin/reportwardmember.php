<?php
include("header.php");
include("config.php");
?>
<html>
<body>
<form method="POST">
  <div class="container" style="width:100%;margin-left:13%;margin-bottom: 8%;" >
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <br />
  
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">WARD MEMBER REPORT</h2>
  <br />
  <br />

  <br>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
  
 <th>S1no</th>
    <th>Ward Name</th>
    <th>Member Count</th>
    
    <?php
	$s=1;
include("config.php");
$result=mysqli_query($con,"Select WardName,count(MemberId) as count from tbl_ward w inner join tbl_family f on w.WardId=f.WId inner join tbl_member m on f.FamilyId=m.FId  group by w.WardId order by count asc");
while($display=mysqli_fetch_array($result))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	
	echo "<td>".$display["WardName"]."</td>";
	echo "<td>".$display["count"]."</td>";
	echo "</tr>";
  
 
   }
   echo "</table>";
   ?>
  
<a href="export_wardmemeber.php?cid=" ><input type="button" name="Export" value="Export" class="btn btn-success" style="margin-left:84%;margin-bottom:8%;"></a>
 </div>
 </br>

  </div>
  </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>