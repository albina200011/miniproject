<?php
include("header.php");
?>
<html>
<head>
</head>
<body>
<?php
include("config.php");
if(isset($_GET["FamilyId"]))
{
	$FamilyId=$_GET["FamilyId"];
	$sql=mysqli_query($con,"SELECT * FROM tbl_family f INNER JOIN tbl_ward w ON w.WardId = F.WId WHERE FamilyId='$FamilyId'");
	$display=mysqli_fetch_array($sql);
}
?>
<form action="" method="POST" style="margin-left:2%;margin-top:5%">
<div class="container" style="width:200%;margin-left:13%;margin-bottom: 5%;" >
  
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
      </div>
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">EDIT FAMILY DETAILS</h2>
<div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">

 <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
<td><label>Ward</label></td>
</div>

      <div class="col-md-6">
      <input type="hidden" class="form-control" name="txt_wardid" readonly="readonly" style="width:500px;" value="<?php echo $display['WId'];?>">
<td><input type="text" class="form-control" name="txt_wardnm" readonly="readonly" style="width:500px;" value="<?php echo $display['WardName'];?>"></td>
</tr>
<tr>
<td><label>Family Register Number</label></td>
<td><input type="text" class="form-control" readonly="readonly" name="txt_regno" style="width:500px;" value="<?php echo $display['FamilyRegNo'];?>"></td>
</tr>
<tr>
<td><label>Family Name</label></td>
<td><input type="text" class="form-control" name="txt_familyname" style="width:500px;" value="<?php echo $display['FamilyName'];?>"></td>
</tr>
<tr>
<td><label>Family Head</label></td>
<td><input type="text" class="form-control" name="txt_familyhead" style="width:500px;" value="<?php echo $display['FamilyHead'];?>"></td>
</tr>
<tr>
<td><label>Contact Number</label></td>
<td><input type="tel" class="form-control" name="txt_contact" style="width:500px;" maxlenght="10" title="Ten digits code" value="<?php echo $display['Contact'];?>"></td>
</tr>
<tr>
<td><label>Username</label></td>
<td><input type="text" class="form-control" name="txt_un" style="width:500px;" value="<?php echo $display['UserName'];?>"></td>
</tr>
<tr>
<td><label>Password</label></td>
<td><input type="password" class="form-control" name="txt_pd" style="width:500px;" value="<?php echo $display['Pwd'];?>"></td>
</tr>
<tr>
<td> <input type="submit" name="btnsubmit" value="Update" class="btn btn-primary" style="margin-left:350%"></td></tr></table>
 </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
if(isset($_POST["btnsubmit"]))
{
	$wid=$_POST["txt_wardid"];
	$regno=$_POST["txt_regno"];
	$fn=$_POST["txt_familyname"];
	$fh=$_POST["txt_familyhead"];
	$cn=$_POST["txt_contact"];
    $un=$_POST["txt_un"];
    $pd=$_POST["txt_pd"];
	$sql=mysqli_query($con,"UPDATE tbl_family SET WId='$wid',FamilyRegNo='$regno',FamilyName='$fn',FamilyHead='$fh',Contact='$cn',UserName='$un',Pwd='$pd' WHERE FamilyId='$FamilyId'");
	if($sql)
	{
		echo "<script>alert('Family Details Updated Successfully!!');window.location='viewfamily.php';</script>";
	}
}
?>
<?php
include("footer.php");
?>
