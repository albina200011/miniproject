
  <?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<form action="holyreg.php" method="post">
  <div class="container" style="width:100%;margin-left:13%;margin-bottom: 5%;" >
  
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
     
    </div>
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">HOLYCOMMUNION DETAILS</h2>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
  
    <th> SlNo</th>
     <th>Name</th>
     <th>Holycommunion Date</th>
   
    
    
    
    
    
    
    
    <th style="color:#F00">View More</th>
   <th style="color:#F00">Accept</th>
   <th style="color:#F00">Decline</th>
    <?php
include("config.php");
$s=1;
$sql=mysqli_query($con,"SELECT * FROM tbl_holycommunion  h inner join tbl_member m on h.MemId=m.MemberId where HolyStatus='0' ");
   while($display=mysqli_fetch_array($sql))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	 echo "<td>".$display["MemberNm"]."</td>";
	echo "<td>".$display["HolyDate"]."</td>";
	
	echo "<td><a style='color:#090' href='holyview.php?HolyId=".$display['HolyId']."'>View More</a> </td>";
	echo "<td><a style='color:#090' href='holyapprove.php?HolyId=".$display['HolyId']."'>Accept</a> </td>";
	echo "<td><a style='color:#090' href='holydecline.php?HolyId=".$display['HolyId']."'>Decline</a> </td>";
	echo "</tr>";
	
  }
echo "</table>";

?>
  </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>