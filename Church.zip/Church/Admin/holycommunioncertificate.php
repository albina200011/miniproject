
<?php
$xmlDoc=new DOMDocument();
$con=mysqli_connect("localhost","root","","dbchurch");
$x=$xmlDoc->getElementsByTagName('link');
//$q=$_GET["q"];


?><head>
<?php
include("config.php");
session_start();
$sid=$_GET["sid"];
$result2=mysqli_query($con,"SELECT * FROM `tbl_certificaterequest` r inner join tbl_member m on r.CMId=m.MemberId inner join tbl_holycommunion d on r.CMId=d.MemId inner join tbl_family f on  m.FId=f.FamilyId where r.CertRequestId='$sid'");

//echo "SELECT * FROM `tbl_certificaterequest` r inner join tbl_member m on r.CMId=m.MemberId inner join tbl_holycommunion d on r.CMId=d.MemId inner join tbl_family f on  m.FId=f.FamilyId where r.CertRequestId='$sid'";
$row2=mysqli_fetch_array($result2); 
?>
</head>
<div class="container" style="width:100%">
        <div class="row">
            <div class="col-md-11">
                <div class="form-horizontal">
                        	 <div class="form-group">
                        			<div class="col-sm-10">
<h3 style="text-align: left;"><input type="button" name ="export" class="btn btn-danger" style="width:95px; height:45px;" value="PRINT" onclick="printdiv('div_print');" ></a><br><br></div></div></div></div></div>
<div id="div_print">
<br><br><br><br>
<table border="2" align="center">
<th>
<table border="0" align="center" height="850" width="600">
<tr>
<th colspan="2"><h2 align="center">ST.MARY's CHURCH AARAKUZHA<br></h2><h4 align="center">Mob:+91 9645 2567 66

 email: stmaryschurchaarakuzha@gmail.com</h4><br></th>
</tr>
<tr>
<th colspan="2"><h2 align="center">HOLY COMMUNION CERTIFICATE<br></h2><br><br></th>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NAME<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['MemberNm']?><br><br></td>
</tr>


<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;HOLY COMMUNION DATE<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['HolyDate']; ?><br><br></td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;HOLY COMMUNION CHURCH<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['HolyChurch']; ?><br><br></td>
</tr>
<tr>
<td><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DATE : <?php echo date('d-m-y'); ?></td><td><br><br>VICAR</td>
</tr>
</table>
<br><br><br>
</th>
</table>
</div>
<script>
function printdiv(printpage)
{
var headstr = "<html><head><title></title></head><body>"; 
var footstr = "</body>";
var newstr = document.all.item(printpage).innerHTML;
var oldstr = document.body.innerHTML;
document.body.innerHTML = headstr+newstr+footstr;
window.print();
document.body.innerHTML = oldstr;
return false;
}
</script>
<?php
include("footer.php");
?>
