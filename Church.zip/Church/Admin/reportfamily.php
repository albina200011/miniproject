<?php
session_start();
include("header.php");
include("config.php");
?>
<html>
<body>
<form method="POST">
  <div class="container" style="width:100%;margin-left:13%;margin-bottom: 8%;" >
  
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <br />
  <br />
  
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">FAMILY REPORT</h2>
  <br />

  <div class="row" style="    margin-left:5%;">
    <div class="col-md-3" style="text-align:right">
      <label>Ward Name</label>
    </div>
    <div class="col-md-3">
      <?php
$sql=mysqli_query($con,"SELECT * FROM tbl_ward");
?>
      <select name="WardName" id="WardName" class="form-control" style="width:500px;" onChange="">
        <option value="0">---Select---</option>
        <?php
while($row=mysqli_fetch_array($sql))
{
?>
        <option value="<?php echo $row['WardId'] ?>"> <?php echo $row['WardName'];?> </option>
        <?php
}
?>
      </select>
      <br />
    </div>
    <br />
    <input type="submit" name="submit" value="View" class="btn btn-primary" style="margin-left: 72%;" >
  </div>
  <br />
  <?php
if(isset($_POST["submit"]))
{
	$WardId=$_POST["WardName"];
?>

  <script>
document.getElementById("WardName").value="<?php echo $WardId ?>";
</script> 
  <br>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
  
    <th>S1no</th>
    <th>Family Registration</th>
    <th>Family Name</th>
    <th>Family Head</th>
    <th>Contact</th>
    
    <?php
	$s=1;
include("config.php");
$result=mysqli_query($con,"Select * from tbl_family where WardId=$WardId");
while($display=mysqli_fetch_array($result))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	
	echo "<td>".$display["FamilyRegistration"]."</td>";
	echo "<td>".$display["FamilyName"]."</td>";
	echo "<td>".$display["FamilyHead"]."</td>";
	echo "<td>".$display["Contact"]."</td>";	
	echo "</tr>";
  
    }
   echo "</table>";
   ?>
  
<a href="Excel/excel_family.php?cid=<?php echo $WardId;?>" ><input type="button" name="Export" value="Export" class="btn btn-success" style="margin-left:84%;margin-bottom:8%;"></a>
 </div>
 </br>
<?php
}
   
?>
  
  </div>
  </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>