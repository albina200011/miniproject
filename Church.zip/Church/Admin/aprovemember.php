<?php
include("header.php");
include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['_id']))
{
 $MemberId=$_GET['_id'];
  $result=mysqli_query($con,"UPDATE tbl_member SET MemberStatus='1' where MemberId=$MemberId");
  
}
if($result)
{
echo "<script>alert('Member details has been accepted successfully. Thank you');window.location='viewmember.php';</script>";
}
?>
<?php
include("footer.php");
?>
