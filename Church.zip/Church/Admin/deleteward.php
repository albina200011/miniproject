<?php
include("config.php");
if(isset($_GET["WardId"]))
{
	$WardId=$_GET["WardId"];
	mysqli_query($con, "UPDATE  tbl_ward set WardStatus=1 where WardId=$WardId");
	echo "<script>alert('Ward Details Deleted Successfully!!');window.location='view_ward.php'</script>";
}
?>