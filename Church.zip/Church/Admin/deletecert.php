<?php
include("config.php");
if(isset($_GET["CId"]))
{
	$CId=$_GET["CId"];
	mysqli_query($con, "UPDATE  tbl_certificatemaster set CStatus=1 where CertificateId=$CId");
	echo "<script>alert('Certificate Details Deleted Successfully!!');window.location='viewcert.php'</script>";
}
?>