  <?php
include("header.php");
include("config.php");
?>
<form action="" method="post">
<div class="container" style="width:100%;margin-left:15%;margin-bottom: 213px;" >
  <div class="row">
    <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
      <h3 style="text-align: center;margin-top:4%;margin-bottom:2%">COUNT OF FAMILY IN WARD WISE</h3>
      <div class="form-horizontal" style="margin-left:0px;">
        <div class="form-group">
        <input type="submit" name="list" value="VIEW IN GRAPH" class="btn btn-danger" style="width:188px; height:35px;  " formaction="wardreport.php">
          <input type="submit" name="export" value="EXPORT" class="btn btn-danger" style="width:75px; height:35px;" formaction="export_count_family.php">
          <br><br><br>
   
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
  
    <th>S1no</th>
   
    <th>Ward Name</th>
   <th>Count</th>
    <?php
	$s=1;
include("config.php");
$result=mysqli_query($con,"SELECT count(*) as count ,WardName FROM `tbl_family` f inner join tbl_ward w on f.WId=w.WardId group by f.WId order by count asc");
while($display=mysqli_fetch_array($result))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	
	
	echo "<td>".$display["WardName"]."</td>";
	echo "<td>".$display["count"]."</td>";
	echo "</tr>";
  
    }
   echo "</table>";
   ?>
  
<a href="export_count_family.php" ><input type="button" name="Export" value="Export" class="btn btn-success" style="margin-left:84%;margin-bottom:8%;"></a>
 </div>
 </br>
<?php

   
?>
  
  </div>
         </form>
           </div>
           </div>
           </div>
           </div>
           </div>
<?php
include("footer.php");
?>