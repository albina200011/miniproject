<?php
include("header.php");
include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['_id']))
{
 $deathid=$_GET['_id'];
  $result=mysqli_query($con,"UPDATE tbl_death SET DeathStatus='rejected' where DeathId=$deathid");
  
}
if($result)
{
echo "<script>alert('Death details has been removed successfully. Thank you');window.location='viewdeath.php';</script>";
}
?>