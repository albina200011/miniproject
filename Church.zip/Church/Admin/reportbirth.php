<?php
session_start();
include("header.php");
include("config.php");
?>
<html>
<body>
<form method="POST">
  <div class="container" style="width:100%;margin-left:13%;margin-bottom: 8%;" >
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <br />
  
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">BIRTHDAY REPORT</h2>
  <br />
  <br />
  <div class="row" style="    margin-left:5%;">
    <div class="col-md-3" style="text-align:right">
      <label>Month</label>
    </div>
    <div class="col-md-3">
      <?php
$sql=mysqli_query($con,"SELECT * FROM tbl_member");
?>
      <select name="MemberDOB" id="MemberDOB" class="form-control" style="width:500px;" onChange="">
        <option value="0">---Select---</option>
        <option value="01">January</option>
        <option value="02">February</option>
        <option value="03">March</option>
        <option value="04">April</option>
        <option value="05">May</option>
        <option value="06">June</option>
        <option value="07">July</option>
        <option value="08">August</option>
        <option value="09">September</option>
        <option value="10">October</option>
        <option value="11">November</option>
        <option value="12">December</option>

      </select>
      <br />
    </div>
    <br />
    <input type="submit" name="submit" value="View" class="btn btn-primary" style="margin-left: 72%;" >
  </div>
  <br />
  <?php
if(isset($_POST["submit"]))
{
	$MemberId=$_POST["MemberDOB"];
?>
 <script>
document.getElementById("MemberDOB").value="<?php echo $MemberId ?>";
</script> 
  <br>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
  
     <th>S1no</th>
    <th>Name</th>
    <th>Gender</th>
    <th>Contact</th>
    <th>Email</th>
    <th>Date of Brith</th>
    
    <?php
	$s=1;
include("config.php");
$result=mysqli_query($con,"Select * from tbl_member where month(MDob)=$MemberId");
while($display=mysqli_fetch_array($result))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	
	echo "<td>".$display["MemberNm"]."</td>";
	echo "<td>".$display["MGender"]."</td>";
	echo "<td>".$display["ConNo"]."</td>";
	echo "<td>".$display["MEmail"]."</td>";	
	echo "<td>".$display["MDob"]."</td>";	
	echo "</tr>";
  
 
   }
   echo "</table>";
   ?>
  
<a href="export_birth.php?cid=<?php echo $MemberId;?>" ><input type="button" name="Export" value="Export" class="btn btn-success" style="margin-left:84%;margin-bottom:8%;"></a>
 </div>
 </br>
<?php
}
   
?>
  </div>
  </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>