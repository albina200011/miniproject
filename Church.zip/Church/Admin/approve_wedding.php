<?php
include("header.php");
include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['_id']))
{
 $weddingid=$_GET['_id'];
  $result=mysqli_query($con,"UPDATE tbl_wedding SET WStatus='accepted' where WeddId=$weddingid");
  
}
if($result)
{
echo "<script>alert('Wedding details has been accepted successfully. Thank you');window.location='viewwedding.php';</script>";
}
?>
<?php
include("footer.php");
?>
