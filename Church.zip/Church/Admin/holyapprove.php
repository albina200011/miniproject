<?php
include("header.php");
include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['HolyId']))
{
 $HolyId=$_GET['HolyId'];
  $result=mysqli_query($con,"UPDATE tbl_holycommunion SET HolyStatus='1' where HolyId=$HolyId");
  
}
if($result)
{
echo "<script>alert('holycommunion details has been accepted successfully. Thank you');window.location='viewholy.php';</script>";
}
?>
<?php
include("footer.php");
?>
