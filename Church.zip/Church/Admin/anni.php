<?php
session_start();
include("header.php");
include("config.php");
?>
<html>
<body>
<form method="POST">
  <div class="container" style="width:100%;margin-left:13%;margin-bottom: 8%;" >
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <br />
  
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">WEDDIND ANNIVERSARY</h3>
                		<div class="form-horizontal" style="margin-left:150px;">
                        	 <div class="form-group">
                        			<div class="col-sm-10">
                                    <div class="form-group" style="margin-top:10px;">
                        		<label class="control-label col-sm-2" for="familyname">YEAR</label>
                        			<div class="col-sm-10">
                           				<input type="text" name="txtyear" style="width:500px;">
                        			</div>
                    	</div>
                        <div class="form-group" style="margin-top:10px;">
                        		<label class="control-label col-sm-2" for="familyname">LENGTH</label>
                        			<div class="col-sm-10">
                           				<input type="text" name="txtlen" style="width:500px;">
                                        <div class="col-sm-6">
                                        <br>
                        				<input type="submit" name ="Save" value="SEARCH" class="btn btn-danger" style="width:95px; height:35px;">
                    	</div>
                        			</div>
                    	
                        </div>
                        </div>
                        </div>
</form>
<?php
if(isset($_POST["Save"]))
	{
		$y=$_POST['txtyear'];
		$l=$_POST['txtlen'];
		$y=$y-$l; 
		$_SESSION["y"]=$y;
		$res=mysqli_query($con,"SELECT w.*,m1.MemberNm as groom,m2.MemberNm as bride FROM tbl_wedding w inner join tbl_member m1  on m1.MemberId=w.Groom inner join tbl_member m2 on m2.MemberId=w.Bride WHERE  year(WDate) like '$y%'");
		//echo "SELECT w.*,m1.MemberFname as groom,m2.MemberFname as bride FROM tbl_wedding w inner join tbl_member m1  on m1.MemberId=w.GroomId inner join tbl_member m2 on m2.MemberId=w.BrideId WHERE w.WeddingStatus='pending' and WeddingDate like '$y%'";
		?>
		<div class="container" style="width:90%">
        <div class="row">
            <div class="col-md-11" >
                <h3 style="text-align: center">MARRIAGE DETAILS</h3>
        <!-- <a href="Excel/excel_anni.php?cid=<?php echo $y;?>" ><input type="button" name="Export" value="Export" class="btn btn-success" style="margin-left:84%;margin-bottom:8%;"></a>-->
                            
                             <table class="table table-hover" style="border: 2px solid #adaaaa;">
                        <thead>
                            <tr>
                                <th scope="col">SL NO</th>
                                <th scope="col">GROOM</th>
                                <th scope="col">BRIDE</th>
                                <th scope="col">WEDDING DATE</th>
                                <th scope="col">PRIEST</th>
                                <th scope="col">CHURCH</th>

                            </tr>
                        </thead>
                        
                        <?php
						$slno=1;
							while($row=mysqli_fetch_array($res))
							{
								
								echo  "<tr>";
								echo "<td>" .$slno++."</td>";
								echo "<td>" .$row['groom']."</td>";
								echo "<td>" .$row['bride']."</td>";
								echo "<td>" .$row['WDate']."</td>";
								echo "<td>" .$row['WPriest']."</td>";
								echo "<td>" .$row['WChurch']."</td>";
								echo "</tr>";
							}
						?>

                    </table>
       
   <?php
	}
?>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php
include('footer.php');
?>
                        
                        
                      
                           				