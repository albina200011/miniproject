<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
include("config.php");
?>
<form action="add_wardaction.php" method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:93px; margin-bottom:10%;padding-left:130px; box-shadow: 2px 2px 10px #1b93e1; border-radius: 4px; top: 14px; margin-top: 3%;">
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">WARD REGISTRATION</h2>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Ward Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_wardname" style="width:500px;" placeholder="Enter Ward Name" pattern="^[A-Za_z][A-Za-z -]+$" required>
      </div>
    </div>
       <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Ward Short Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_wardshortname" style="width:500px;" placeholder="Enter Ward Short Name" pattern="^[A-Za_z][A-Za-z -]+$"  required autofocus>
      </div>
    </div>
    <br>
     <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Discription:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_discription" style="width:500px;height:200px" placeholder="Enter Ward Discription" required>
      </div>
    </div>
    <br>
     <div class="row">
      <input type="submit" name="btnsubmit" value="Save" class="btn btn-primary" style="margin-left:63%">
    </div>
    <br>
     </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>
