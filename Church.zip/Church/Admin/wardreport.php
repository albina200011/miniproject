 <?php
include("header.php");
include("config.php");
$query ="SELECT WardName, count( FamilyId ) FROM tbl_family f INNER JOIN tbl_ward w ON w.WardId=f.WId GROUP BY f.WId";
$res =$con-> query($query);
?>
<html>
<head>
 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['f_name', 'number'],
        <?php
		while ($row=$res->fetch_assoc())
		{
			echo "['".$row['WardName']."',".$row['count']."],";
		}
		?>
        ]);

        var options = {
          title: 'percentage',
		  is3D:true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
</head>
<body>
<form action="" method="post">
<div class="container" style="width:100%;margin-left:15%;margin-bottom: 213px;" >
  <div class="row">
    <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
      <h3 style="text-align: center;margin-top:4%;margin-bottom:2%">COUNT OF FAMILY IN WARD WISE</h3>
      <div class="form-horizontal" style="margin-left:0px;">
        <div class="form-group">
        <input type="submit" name="list" value="VIEW IN TABLE" class="btn btn-danger" style="width:188px; height:35px;  " formaction="table_ward_family.php">
          <input type="submit" name="export" value="EXPORT" class="btn btn-danger" style="width:75px; height:35px;" formaction="export_count_family.php">
          <br>

    <div id="piechart" style="width: 900px; height: 500px;"></div>
         </form>
           </div>
           </div>
           </div>
           </div>
           </div>
           </body>
<?php
include("footer.php");
?>


