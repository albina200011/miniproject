<?php
include("config.php");
if(isset($_POST["btnsubmit"]))
{
	$Type=$_POST['txt_type'];
	$CName=$_POST['txt_cname'];
	$CDiscrition=$_POST['txt_cdiscription'];
		
	$sql=mysqli_query($con,"select * from tbl_certificatemaster WHERE CertificateName='$CName'"); 
$row=mysqli_fetch_array($sql);
if($row>0)
{
	echo "<script>alert('Certificate Details Already Exists !!');window.location='viewcert.php'</script>";
}
else
{
$sql=mysqli_query($con,"INSERT INTO tbl_certificatemaster(CertificateType,CertificateName,CDescription)VALUES('$Type','$CName','$CDiscrition')");

if($sql)
  {
	 
echo "<script>alert('Certificate Details Registered Successfully!!');window.location='viewcert.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='viewcert.php'</script>";
  }}
}

?>
