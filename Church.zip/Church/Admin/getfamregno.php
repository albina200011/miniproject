<?php
$con=mysqli_connect("localhost","root","","dbchurch");


 $pname=$_POST['pname'];
 $housename=$_POST['housename'];

     $sql=mysqli_query($con,"SELECT FamilyRegNo FROM `tbl_member` m inner join tbl_family f on m.FId=f.FamilyId where MemberNm='$pname' and FamilyName='$housename'");
    $row=mysqli_fetch_array($sql);
   if($row>0)
   {
     ?>
    
    
     <div class="row" 
      <div class="col-md-3" style="text-align:left">
        <label style="margin-left: 31px;">Family Register Number:</label>
      </div>
      <div class="col-md-6">
        <input type="text" placeholder=" Family Register Number" class="form-control" style="    margin-left: 100px;" value="<?php echo $row["FamilyRegNo"] ?>" readonly name="txt_freg" style="width:500px;">
      </div>
    </div>
    <?php
   }
   else
   {
   ?>
    <label style="margin-left: 31px;">Family  Register Number Not Found!! </label>
<?php

   }
   ?>
    
    