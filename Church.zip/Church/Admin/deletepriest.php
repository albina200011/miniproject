<?php
include("config.php");
if(isset($_GET["PriestId"]))
{
	$PriestId=$_GET["PriestId"];
	mysqli_query($con, "UPDATE  tbl_priest set PriestStatus=1 where PriestId=$PriestId");
	echo "<script>alert('Priest Details Deleted Successfully!!');window.location='viewpriest.php'</script>";
}
?>