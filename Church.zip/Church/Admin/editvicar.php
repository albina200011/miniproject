<?php
include("header.php");
?>
<html>
<head>
</head>
<body>
<?php
include("config.php");
if(isset($_GET["VicarId"]))
{
	$VicarId=$_GET["VicarId"];
	$sql=mysqli_query($con,"SELECT * FROM tbl_vicar WHERE VicarId='$VicarId'");
	$display=mysqli_fetch_array($sql);
}
?>
<form action="" method="POST" style="margin-left:2%;margin-top:5%">
<div class="container" style="width:200%;margin-left:13%;margin-bottom: 5%;" >
  
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
      </div>
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">EDIT VICAR DETAILS</h2>
<div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">

 <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
<td><label>Vicar Name</label></td>
</div>

      <div class="col-md-6">
<td><input type="text" class="form-control" name="txt_vicarname" style="width:500px;" value="<?php echo $display['VicarName'];?>"></td>
</tr>
<tr>
<td><label>House Name</label></td>
<td><input type="text" class="form-control" name="txt_housename" style="width:500px;" value="<?php echo $display['HouseName'];?>"></td>
</tr>
<tr>
<td><label>Diocese</label></td>
<td><input type="text" class="form-control" name="txt_diocese" style="width:500px;" value="<?php echo $display['Diocese'];?>"></td>
</tr>
<tr>
<td><label>Year Of Joining</label></td>
<td><input type="text" class="form-control" name="txt_yearofjoining" style="width:500px;" value="<?php echo $display['YearofJoining'];?>"></td>
</tr>
<tr>
<td><label>Year Of Leaving</label></td>
<td><input type="text" class="form-control" name="txt_yearofleaving" style="width:500px;" value="<?php echo $display['YearofLeaving'];?>"></td>
</tr>
<tr>
<td><label>Date Of Birth</label></td>
<td><input type="date" class="form-control" name="txt_dateofbirth" style="width:500px;" value="<?php echo $display['DateofBirth'];?>"></td>
</tr>
<tr>
<td><label>Feast Day</label></td>
<td><input type="text" class="form-control" name="txt_feastday" style="width:500px;" value="<?php echo $display['FeastDay'];?>"></td>
</tr>
<tr>
<td><label>Contact Number</label></td>
<td><input type="tel" class="form-control" name="txt_contactno" style="width:500px;" maxlenght="10" title="Ten digits code" value="<?php echo $display['ContactNo'];?>"></td>
</tr>
<tr>
<td> <input type="submit" name="btnsubmit" value="Update" class="btn btn-primary" style="margin-left:403%"></td></tr></table>
 </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
if(isset($_POST["btnsubmit"]))
{
	$vname=$_POST["txt_vicarname"];
	$hname=$_POST["txt_housename"];
	$d=$_POST["txt_diocese"];
	$yoj=$_POST["txt_yearofjoining"];
	$yol=$_POST["txt_yearofleaving"];
	$dob=$_POST["txt_dateofbirth"];
	$fd=$_POST["txt_feastday"];
	$cn=$_POST["txt_contactno"];
	$sql=mysqli_query($con,"UPDATE tbl_vicar SET VicarName='$vname',HouseName='$hname',Diocese='$d',YearofJoining='$yoj',YearofLeaving='$yol',DateofBirth='$dob',FeastDay='$fd',ContactNo='$cn' WHERE VicarId='$VicarId'");
	if($sql)
	{
		echo "<script>alert('Vicar Details Updated Successfully!!');window.location='viewvicar.php';</script>";
	}
}
?>
<?php
include("footer.php");
?>
