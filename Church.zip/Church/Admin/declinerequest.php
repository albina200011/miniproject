<?php
include("header.php");
include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['_id']))
{
 $crId=$_GET['_id'];
  $result=mysqli_query($con,"UPDATE tbl_certificaterequest SET CertStatus='rejected' where CertRequestId=$crId");
  
}
if($result)
{
echo "<script>alert('Request details has been removed successfully. Thank you');window.location='viewreq.php';</script>";
}
?>