<?php
include("config.php");
if(isset($_POST["btnsubmit"]))
{
	$PriestName=$_POST['txt_priestname'];
    $DOB=$_POST['txt_dob'];
	$HouseName=$_POST['txt_housenm'];
    $Freg=$_POST['txt_freg'];
	$Diocese=$_POST['txt_dio'];
    $Congregation=$_POST['txt_congregation'];
    $Don=$_POST['txt_on'];
    $Pn=$_POST['rbcat'];
    	$ContactNo=$_POST['txt_contact'];
		
		
$sql=mysqli_query($con,"INSERT INTO tbl_priest(PriestName,DOB,HouseNm,FReg,Dio,Congregation,DateON,PN,Con)VALUES('$PriestName','$DOB','$HouseName','$Freg','$Diocese','$Congregation','$Don','$Pn','$ContactNo')");

if($sql)
  {
	 
echo "<script>alert('Priest Details Registered Successfully!!');window.location='viewpriest.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='viewpriest.php'</script>";
  }
}

?>
