<?php
include("header.php");
?>
<html>
<head>
</head>
<body>
<?php
include("config.php");
if(isset($_GET["CId"]))
{
	$CId=$_GET["CId"];
	$sql=mysqli_query($con,"SELECT * FROM tbl_certificatemaster WHERE CertificateId='$CId'");
	$display=mysqli_fetch_array($sql);
}
?>
<form action="" method="POST" style="margin-left:2%;margin-top:5%">
<div class="container" style="width:200%;margin-left:13%;margin-bottom: 5%;" >
  
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
      </div>
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">EDIT CERTIFICATE DETAILS</h2>
<div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">

 <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
<td><label>Certificate Type</label></td>
</div>

      <div class="col-md-6">
<td><input type="text" class="form-control" name="txt_type" style="width:500px;" value="<?php echo $display['CertificateType'];?>"></td>
</tr>
<tr>
<td><label>Certificate Name</label></td>
<td><input type="text" class="form-control" name="txt_cname" style="width:500px;" value="<?php echo $display['CertificateName'];?>"></td>
</tr>
<tr>
<td><label>Discription</label></td>
<td><input type="text" class="form-control" name="txt_cdiscription" style="width:500px;height:200px" value="<?php echo $display['CDescription'];?>"></td>
</tr>
<tr>
<td> <input type="submit" name="btnsubmit" value="Update" class="btn btn-primary" style="margin-left:403%"></td></tr></table>
 </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
if(isset($_POST["btnsubmit"]))
{
	$type=$_POST["txt_type"];
	$cname=$_POST["txt_cname"];
	$cdiscription=$_POST["txt_cdiscription"];
	$sql=mysqli_query($con,"UPDATE tbl_certificatemaster SET CertificateType='$type',CertificateName='$cname',CDescription='$cdiscription' WHERE CertificateId='$CId'");
	if($sql)
	{
		echo "<script>alert('Certificate Details Updated Successfully!!');window.location='viewcert.php';</script>";
	}
}
?>
<?php
include("footer.php");
?>
