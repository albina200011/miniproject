<?php
include("config.php");
if(isset($_POST["btnsubmit"]))
{
	$WardName=$_POST['txt_wardname'];
	$WardShortName=$_POST['txt_wardshortname'];
	$WardDiscrition=$_POST['txt_discription'];
		$sql=mysqli_query($con,"SELECT count(*) as count FROM tbl_ward WHERE WardName='$WardName'");
  		$display=mysqli_fetch_array($sql);
  		if($display['count']>0)
		{
		echo "<script>alert('This ward name is already exist');window.location='reg_ward.php'</script>";	
		}
		else
		{
$sql=mysqli_query($con,"INSERT INTO tbl_ward(WardName,WardShortName,WardDiscription,WardStatus)VALUES('$WardName','$WardShortName','$WardDiscrition','0')");

if($sql)
  {
	 
echo "<script>alert('Ward Details Registered Successfully!!');window.location='view_ward.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='view_ward.php'</script>";
  }
}
}
?>
