<?php
include("header.php");
?>
<html>
<head>
</head>
<body>
<?php
include("config.php");
if(isset($_GET["PriestId"]))

{
	$PriestId=$_GET["PriestId"];
	$sql=mysqli_query($con,"SELECT * FROM tbl_priest WHERE PriestId='$PriestId'");
	$display=mysqli_fetch_array($sql);
}
?>
<form action="" method="POST" style="margin-left:2%;margin-top:5%">
<div class="container" style="width:200%;margin-left:13%;margin-bottom: 5%;" >
  
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
      </div>
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">EDIT PRIEST DETAILS</h2>
<div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">

 <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
<td><label>Priest Name</label></td>
</div>

      <div class="col-md-6">
<td><input type="text" class="form-control" name="txt_priestname" style="width:500px;" value="<?php echo $display['PriestName'];?>"></td>
</tr>
<tr>
<td><label>Date Of Birth</label></td>
<td><input type="date" class="form-control" name="txt_dob" style="width:500px;" value="<?php echo $display['DOB'];?>"></td>
</tr>
<tr>
<td><label>House Name</label></td>
<td><input type="text" class="form-control" name="txt_housenm" style="width:500px;" value="<?php echo $display['HouseNm'];?>"></td>
</tr>
<tr>
<td><label>Family Register Number</label></td>
<td><input type="text" class="form-control" name="txt_freg" style="width:500px;" value="<?php echo $display['FReg'];?>"></td>
</tr>
<tr>
<td><label>Diocese</label></td>
<td><input type="text" class="form-control" name="txt_dio" style="width:500px;" value="<?php echo $display['Dio'];?>"></td>
</tr>
<tr>
<td><label>Congregation</label></td>
<td><input type="text" class="form-control" name="txt_congregation" style="width:500px;" value="<?php echo $display['Congregation'];?>"></td>
</tr>
<tr>
<td><label>Date Of Ordination/novitiate</label></td>
<td><input type="date" class="form-control" name="txt_on" style="width:500px;" value="<?php echo $display['DateON'];?>"></td>
</tr>
<tr>
<td><label>Category</label></td>
<td><input type="radio" name="rbcat" value="  Priest" value="<?php echo $display['PN'];?>"/>  Priest
     <input type="radio" name="rbcat" value="  Nuns" value="<?php echo $display['PN'];?>"/>  Nuns</td>
</tr>


<tr>
<td><label>Contact Number</label></td>
<td><input type="tel" class="form-control" name="txt_contact" style="width:500px;" maxlenght="10" title="Ten digits code" value="<?php echo $display['Con'];?>"></td>
</tr>
<tr>
<td> <input type="submit" name="btnsubmit" value="Update" class="btn btn-primary" style="margin-left:300%"></td></tr></table>
 </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
if(isset($_POST["btnsubmit"]))
{
	$pname=$_POST["txt_priestname"];
	$dob=$_POST["txt_dob"];
	$hname=$_POST["txt_housenm"];
	$freg=$_POST["txt_freg"];
	$dio=$_POST["txt_dio"];
	$cn=$_POST["txt_congregation"];
	$on=$_POST["txt_on"];
    $ca=$_POST["rbcat"];
	$cno=$_POST["txt_contact"];
	$sql=mysqli_query($con ,"UPDATE tbl_priest SET PriestName='$pname',DOB='$dob',HouseNm='$hname',FReg='$freg',Dio='$dio',Congregation='$cn',DateON='$on',PN='$ca',Con='$cno' WHERE PriestId='$PriestId'");
	if($sql)
	{
		echo "<script>alert('Priest Details Updated Successfully!!');window.location='viewpriest.php';</script>";
	}
}
?>
<?php
include("footer.php");
?>
