<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
include("config.php");
?>
<form action="actionvicar.php" method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:93px; margin-bottom:10%;padding-left:130px; box-shadow: 2px 2px 10px #1b93e1; border-radius: 4px; top: 14px; margin-top: 3%;">
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">VICAR REGISTRATION</h2>

 
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Vicar Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_vicarname" style="width:500px;" placeholder="Enter Vicar Name" pattern="^[A-Za_z][A-Za-z -]+$" required>
      </div>
    </div>
       <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>House Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_housename" style="width:500px;" placeholder="Enter House Name" pattern="^[A-Za_z][A-Za-z -]+$" required >
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Diocese:</label> 
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_diocese" style="width:500px;" placeholder="Enter  Diocese" pattern="^[A-Za_z][A-Za-z -]+$" required>
      </div>
    </div>
    <br>
    <div class="row">
    
     <div class="col-md-3" style="text-align:left">
        <label>Year Of Joining:</label>
      </div>
      <div class="col-md-6">
        <input type="text" pattern="[0-9]{4}" class="form-control" name="txt_yearofjoining" style="width:500px;" placeholder="Enter  Year Of Joining" required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Year Of Leaving:</label>
      </div>
      <div class="col-md-6">
        <input type="year" pattern="[0-9]{4}" class="form-control" name="txt_yearofleaving" style="width:500px;" placeholder="Enter Year Of Leaving" required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Date Of Birth:</label>
      </div>
      <div class="col-md-6">
        <input type="date" class="form-control" name="txt_dateofbirth" style="width:500px;" max="<?php echo date('Y-m-d') ?>" required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Feast Day:</label>
      </div>
      <div class="col-md-6">
        <input type="date" class="form-control" name="txt_feastday" style="width:500px;" max="<?php echo date('Y-m-d') ?>" required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Contact Number:</label>
      </div>
      <div class="col-md-6">
        <input type="tel" class="form-control" name="txt_contactno" style="width:500px;" pattern="[0-9]{10}"  title="Ten digits code" placeholder="Enter Contact number" required>
      </div>
    </div>
    <br>
    <div class="row">
    
    
      <input type="submit" name="btnsubmit" value="Save" class="btn btn-primary" style="margin-left:63%">
    </div>
    <br>
     </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>
