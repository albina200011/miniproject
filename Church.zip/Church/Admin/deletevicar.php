<?php
include("config.php");
if(isset($_GET["VicarId"]))
{
	$VicarId=$_GET["VicarId"];
	mysqli_query($con, "UPDATE  tbl_vicar set VicarStatus=1 where VicarId=$VicarId");
	echo "<script>alert('Vicar Details Deleted Successfully!!');window.location='viewvicar.php'</script>";
}
?>