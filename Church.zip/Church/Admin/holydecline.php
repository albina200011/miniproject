<?php
include("header.php");
include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['HolyId']))
{
$HolyId=$_GET['HolyId'];
  $result=mysqli_query($con,"UPDATE tbl_holycommunion SET HolyStatus='2' where HolyId=$HolyId");
  
}
if($result)
{
echo "<script>alert('Holycommunion details has been removed successfully. Thank you');window.location='viewholy.php';</script>";
}
?>