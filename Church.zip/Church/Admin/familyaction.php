<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{
     $WardId=$_POST['wardid'];
	$FamilyRegister=$_POST['txt_regno'];
	
	$FamilyName=$_POST['txt_familyname'];
    $FamilyHead=$_POST['txt_familyhead'];
    $Contact=$_POST['txt_contact'];
    $Un=$_POST['txt_un'];
	$Pd=$_POST['txt_pd'];
		
		
$sql=mysqli_query($con,"INSERT INTO tbl_family(WId,FamilyRegNo,FamilyName,FamilyHead,Contact,UserName,Pwd)VALUES('$WardId','$FamilyRegister','$FamilyName','$FamilyHead','$Contact','$Un','$Pd')");

if($sql)
  {
	 
echo "<script>alert('Family Details Registered Successfully!!');window.location='viewfamily.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='viewfamily.php'</script>";
  }
}

?>
