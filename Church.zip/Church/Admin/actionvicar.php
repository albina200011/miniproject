<?php
include("config.php");
if(isset($_POST["btnsubmit"]))
{
	$VicarName=$_POST['txt_vicarname'];
	$HouseName=$_POST['txt_housename'];
	$Diocese=$_POST['txt_diocese'];
    $YearOfJoining=$_POST['txt_yearofjoining'];
    $YearOfLeaving=$_POST['txt_yearofleaving'];
    $DateOfBirth=$_POST['txt_dateofbirth'];
    $FeastDay=$_POST['txt_feastday'];
	$ContactNo=$_POST['txt_contactno'];
	$sql=mysqli_query($con,"SELECT count(*) as count FROM tbl_vicar WHERE ContactNo='$ContactNo' AND HouseName='$HouseName'");
  		$display=mysqli_fetch_array($sql);
  		if($display['count']>0)
		{
		echo "<script>alert('This vicar name is already exist');window.location='viewvicar.php'</script>";	
		}
		else
		{
		
		
$sql=mysqli_query($con,"INSERT INTO tbl_vicar(VicarName,HouseName,Diocese,YearofJoining,YearofLeaving,DateofBirth,FeastDay,ContactNo)VALUES('$VicarName','$HouseName','$Diocese','$YearOfJoining','$YearOfLeaving','$DateOfBirth','$FeastDay','$ContactNo')");

if($sql)
  {
	 
echo "<script>alert('Vicar Details Registered Successfully!!');window.location='viewvicar.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='viewvicar.php'</script>";
  }
}
}
?>
