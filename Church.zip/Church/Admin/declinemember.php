<?php
include("header.php");
include("config.php");
?>

<form action="" method="POST">

<div class="container" style="margin-left:250px;">
<?php
if(isset($_GET['_id']))
{
 $MemberId=$_GET['_id'];
  $result=mysqli_query($con,"UPDATE tbl_member SET MemberStatus='2' where MemberId=$MemberId");
  
}
if($result)
{
echo "<script>alert('member details has been removed successfully. Thank you');window.location='viewmember.php';</script>";
}
?>