<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
include("config.php");
$sql=mysqli_query($con,"SELECT ifnull(count(FamilyRegNo),0)+1001 as  FamilyRegNo FROM tbl_family");

$row=mysqli_fetch_array($sql);
?>
<form action="familyaction.php" method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:93px; margin-bottom:10%;padding-left:130px; box-shadow: 2px 2px 10px #1b93e1; border-radius: 4px; top: 14px; margin-top: 3%;">
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">FAMILY REGISTRATION</h2>

 <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Family Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_familyname" style="width:500px;" placeholder="Enter Family Name" pattern="^[A-Za_z][A-Za-z -]+$"    required>
      </div>
    </div>
   
   
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Family Register Number:</label>
      </div>
      <div class="col-md-6">
        <input type="text" readonly class="form-control"  name="txt_regno" style="width:500px;"  value="<?php echo $row['FamilyRegNo'];?>"   required>
      </div>
    </div>
    <br>
    
    <div class="row">
     <div class="col-md-3" style="text-align:left">
    <?php
$con=mysqli_connect("localhost","root","","dbchurch");


$sql=mysqli_query($con,"select * from tbl_ward WHERE WardStatus=0"); 
?>
<label>Ward Name</label><br>
 </div>
      <div class="col-md-6">
<select name="wardid" onchange="showResult(this.value)"  class="form-control" required >
<option value="">--select--</option>
<?php
while($row=mysqli_fetch_array($sql))
{

?>
<option value="<?php echo $row[0] ?>" ><?php echo $row[1] ?></option>
<?php
	
}
?>

</select>
</div>
</div>
        <br>
    
    <div class="row">
    
    
     <div class="col-md-3" style="text-align:left">
        <label>Family Head:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_familyhead" style="width:500px;" placeholder="Enter Family Head" pattern="^[A-Za_z][A-Za-z -]+$" required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Contact Number:</label>
      </div>
      <div class="col-md-6">
        <input type="tel" class="form-control" name="txt_contact" style="width:500px;" placeholder="Enter Contact Number"  pattern="[0-9]{10}" required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Username:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_un" style="width:500px;" placeholder="Enter Username"   required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Password:</label>
      </div>
      <div class="col-md-6">
        <input type="password" class="form-control" name="txt_pd" style="width:500px;" placeholder="Enter Password"  required>
      </div>
    </div>
    <br>
    
    <div class="row">
    
    
      <input type="submit" name="btnsubmit" value="Save" class="btn btn-primary" style="margin-left:63%">
    </div>
    <br>
     </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>
