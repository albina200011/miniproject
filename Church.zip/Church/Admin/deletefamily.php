<?php
include("config.php");
if(isset($_GET["FamilyId"]))
{
	$FamilyId=$_GET["FamilyId"];
	mysqli_query($con, "UPDATE  tbl_family set FamilyStatus=1 where FamilyId=$FamilyId");
	echo "<script>alert('Family Details Deleted Successfully!!');window.location='viewfamily.php'</script>";
}
?>