<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Faith - Church Template | Home</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- ##### Search Wrapper Start ##### -->
    <div class="search-wrapper d-flex align-items-center justify-content-center bg-img foo-bg-overlay" style="background-image: url(img/bg-img/bg-2.jpg);">
       <div class="close--icon">
           <i class="fa fa-times"></i>
       </div>
        <!-- Logo -->
        <a href="index.html" class="search-logo"><img src="img/core-img/logo2.png" alt=""></a>
        <!-- Search Form -->
        <div class="search-form">
            <form action="#" method="get">
                <input type="search" name="search" id="search" placeholder="Enter Your Keywords">
                <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
        </div>
        <!-- Copwrite Text -->
        <div class="copywrite-text">
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Designed by A&A <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
        </div>
    </div>
    <!-- ##### Search Wrapper End ##### -->

    <!-- ##### Preloader ##### -->
    <div id="preloader">
        <div class="circle">
            <img src="img/core-img/church.png" alt="">
        </div>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">
        <!-- Top Header Area -->
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-12 h-100">
                        <div class="top-header-content h-100 d-flex align-items-center justify-content-end">
                            <!-- Next Events Countdown -->
                            <div class="next-events-countdown d-flex align-items-center">
                                <p>Next Big Event:</p>
                                <div class="events-cd" data-countdown="2022/01/01"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="faith-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="faithNav">

                        <!-- Logo -->
                        <a class="nav-brand" href="index.html"><img src="img/core-img/logo.png" alt=""></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                     
                                    
                                  
                                    
                                     
                                     <li><a href="#">Registration</a>
                                                <ul class="dropdown">
                                                 <li><a href="viewvicar.php">Vicar</a></li>
                                                    <li><a href="view_ward.php">Ward</a></li>
                                                    <li><a href="viewfamily.php">Family</a></li>
                                                    <li><a href="viewpriest.php">Priest</a></li>
                                                    <li><a href="viewcert.php">CertificateMaster</a></li>
                                                  
                                                    
                                </ul>
                                </li>
                                 
                                <li><a href="#">Approvals</a>
                                <ul class="dropdown">
                                <li><a href="viewmember.php">Member</a></li>
                                 <li><a href="viewholy.php">Holycommunion</a></li>
                                  <li><a href="approvel_engagement.php">Engagement</a></li>
                                  <li><a href="viewwedding.php">Wedding</a></li>
                                  <li><a href="viewdeath.php">Death</a></li>
                                 
                                </ul>
                                </li>
                                <li><a href="viewreq.php">Certificate Requests</a></li>
                               <li><a href="#">Reports</a>
                                        <ul class="dropdown" style="width: 350%;">
                                           <li><a href="wardreport.php">Count Of Family Report In Ward (Piechart)</a></li>
                                            <li><a href="report_family.php">Family Details Report In Ward Wise</a></li>
                                            <li><a href="reportmember.php">Member Details Report In Family Wise</a></li>
                                       <li><a href="reportdeath.php">Death Report In Ward Wise</a></li>
                                       <li><a href="reportbirth.php">Birthday Report In Month Wise</a></li>
                                       
                                       <li><a href="anni.php">Wedding Report In Year Wise</a></li>
                                      
                                       <li><a href="reportwardmember.php">Member Count in Each Ward</a></li>
                                       <li><a href="table_ward_family.php">Count Of Family Report In Ward Wise</a></li> 
                                       <li><a href="report_prist.php">Preist Report In Ward Wise</a></li>
                                         <li><a href="view_request.php">Certificate Details Report</a></li> </ul>
                                    </li>
                                 </ul>
                               

                                <!-- Search Button -->
                                
                                <!-- Donate Button -->
                                <div class="donate-btn">
                                    <a href="logout.php">Logout</a>
                                </div>

                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->
</body>
</html>