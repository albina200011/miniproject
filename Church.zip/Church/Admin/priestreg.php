<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
include("config.php");
?>
<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
<form action="actionpriest.php" method="post" enctype="multipart/form-data">
  <div class="container" style="margin-left:93px; margin-bottom:10%;padding-left:130px; box-shadow: 2px 2px 10px #1b93e1; border-radius: 4px; top: 14px; margin-top: 3%;">
    <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">PRIEST REGISTRATION</h2>
    <br>
    <div class="row">
      <div class="col-md-3" style="text-align:left">
        <label>Priest Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_priestname"  id="txt_priestname"  style="width:500px;" placeholder="Enter Priest Name" pattern="^[A-Za_z][A-Za-z -]+$"   required>
      </div>
    </div>
    <br>
    <div class="row">
      <div class="col-md-3" style="text-align:left">
        <label>Date Of Birth:</label>
      </div>
      <div class="col-md-6">
        <input type="date" class="form-control" name="txt_dob" style="width:500px;"  required  max="<?php echo date('Y-m-d') ?>" >
      </div>
    </div>
    <br>
    <br>
    <div class="row">
      <div class="col-md-3" style="text-align:left">
        <label>House Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" onChange="populate()" id="txt_housenm" name="txt_housenm" style="width:500px;" placeholder="Enter House Name" pattern="^[A-Za_z][A-Za-z -]+$" required >
      </div>
    </div>
    <br>
    <div class="row"  id="chkboxContainer">
      <div class="col-md-3" style="text-align:left">
        <label>Family Register Number:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" readonly name="txt_freg" style="width:500px;" placeholder=" Family Register Number" required>
      </div>
    </div>
    <br>
    <div class="row">
      <div class="col-md-3" style="text-align:left">
        <label>Diocese:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_dio" style="width:500px;" placeholder="Enter  Diocese" pattern="^[A-Za_z][A-Za-z -]+$" required>
      </div>
    </div>
    <br>
    <div class="row">
      <div class="col-md-3" style="text-align:left">
        <label>Congregation:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_congregation" style="width:500px;" placeholder="Enter Congregation" pattern="^[A-Za_z][A-Za-z -]+$" required>
      </div>
    </div>
    <br>
    <div class="row">
      <div class="col-md-3" style="text-align:left">
        <label>Date Of Ordination/novitiate:</label>
      </div>
      <div class="col-md-6">
        <input type="date" class="form-control" name="txt_on" style="width:500px;" required max="<?php echo date('Y-m-d') ?>" >
      </div>
    </div>
    <br>
    <div class="row">
      <div class="col-md-3" style="text-align:left">
        <label>Category:</label>
      </div>
      <div class="col-md-6">
        <input type="radio" name="rbcat" value="  Priest" checked/>
        Priest
        <input type="radio" name="rbcat" value="  Nuns"/>
        Nuns </div>
    </div>
    <br>
    <div class="row">
      <div class="col-md-3" style="text-align:left">
        <label>Contact Number:</label>
      </div>
      <div class="col-md-6">
        <input type="tel" class="form-control" name="txt_contact" style="width:500px;"  title="Ten digits code" placeholder="Enter Contact number "  pattern="[0-9]{10}" required>
      </div>
    </div>
    <br>
    <div class="row">
      <input type="submit" name="btnsubmit" value="Save" class="btn btn-primary" style="margin-left:63%">
    </div>
    <br>
  </div>
</form>
</body>
</html>
<script>
  	function populate()
    {
	 
     var pname=document.getElementById('txt_priestname').value;
	 var housename=document.getElementById('txt_housenm').value;
//alert(pname);
//alert(housename);
 	 $.ajax({
		type: "POST",
		url: "getfamregno.php",
		data: { pname:pname, housename:housename},
		
		success: function(data){
		$("#chkboxContainer").html(data);	
		}
		})
		
 }
 </script>
<?php
include("footer.php");
?>
