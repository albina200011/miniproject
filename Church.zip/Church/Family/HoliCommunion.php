<?php
include("config.php");

if(isset($_POST["btnsubmit"]))
{
	
	$HolyDateStatus=$_POST['txt_holydate'];
	$holycommunicationdate=$_POST['txt_holydate'];
	
	$memberid=$_POST["drpMemberId"];
	$holycommunicationpriest=$_POST['txt_holypriest'];
	$holycommunicationchurch=$_POST['txt_holychurch'];	
	
	
	
	
	
	
$sql=mysqli_query($con,"INSERT INTO tbl_holycommunion(HolyDate,MemId,HolyChurch,HolyPriest,HolyStatus)VALUES('$holycommunicationdate','$memberid','$holycommunicationchurch','$holycommunicationpriest','0')");

//echo "INSERT INTO tbl_holycommunion(HolyDate,MemId,HolyChurch,HolyPriest,HolyStatus,HolyDateStatus)VALUES('$holycommunicationdate','$memberid','$holycommunicationchurch','$holycommunicationpriest','0',$HolyDateStatus)";
if($sql)
  {
	 
echo "<script>alert('Holy Communication Details Registered Successfully!!');window.location='index.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='index.php'</script>";
  }


}
?>
