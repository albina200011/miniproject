
<?php
$xmlDoc=new DOMDocument();
$con=mysqli_connect("localhost","root","","dbchurch");
$x=$xmlDoc->getElementsByTagName('link');
//$q=$_GET["q"];


?><head>
<?php
include("config.php");
session_start();
$sid=$_GET["sid"];
$result2=mysqli_query($con,"SELECT m1.MemberNm as groomname,m2.MemberNm as bridename,FamilyName,WDate,WPriest,WChurch,WW1,WW2 FROM `tbl_certificaterequest` r inner join tbl_member m on r.CMId=m.MemberId inner join tbl_wedding d on r.CMId=d.Groom inner join tbl_member m1 on d.Groom=m1.MemberId inner join tbl_member m2 on d.Bride=m2.MemberId inner join tbl_family f on  m.FId=f.FamilyId where r.CertRequestId='$sid'");



$row2=mysqli_fetch_array($result2); 
?>
</head>
<div class="container" style="width:100%">
        <div class="row">
            <div class="col-md-11">
                <div class="form-horizontal">
                        	 <div class="form-group">
                        			<div class="col-sm-10">
<h3 style="text-align: left;"><input type="button" name ="export" class="btn btn-danger" style="width:95px; height:45px;" value="PRINT" onclick="printdiv('div_print');" ></a><br><br></div></div></div></div></div>
<div id="div_print">
<br><br><br><br>
<table border="2" align="center">
<th>
<table border="0" align="center" height="850" width="600">
<tr>
<th colspan="2"><h2 align="center">ST.MARY's CHURCH AARAKUZHA<br></h2><h4 align="center">Mob:+91 9645 2567 66

 email: stmaryschurchaarakuzha@gmail.com</h4><br></th>
</tr>
<tr>
<th colspan="2"><h2 align="center">WEDDING CERTIFICATE<br></h2><br><br></th>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GROOM<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['groomname']; ?><br><br></td>
</tr>

<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BRIDE<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['bridename'] ?><br><br></td>
</tr>

<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;HOUSE NAME<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['FamilyName']; ?><br><br></td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;WEDDING DATE<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['WDate']; ?><br><br></td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PRIEST<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['WPriest']; ?><br><br></td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CHURCH<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['WChurch']; ?><br><br></td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;WITNESS 1<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['WW1']; ?><br><br></td>
</tr>
<tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;WITNESS 2<br><br></td><td>:&nbsp;&nbsp;&nbsp; <?php echo $row2['WW2']; ?><br><br></td>
</tr>
<tr>
<td><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DATE : <?php echo date('d-m-y'); ?></td><td><br><br>VICAR</td>
  <td><img src="img/seal.jpg" style="    margin-left: -132%;
    height: 800%;
    width: 600%;
    margin-bottom: -83%;" /></td>
</tr>
</table>
<br><br><br>
</th>
</table>
</div></div></div>
<script>
function printdiv(printpage)
{
var headstr = "<html><head><title></title></head><body>"; 
var footstr = "</body>";
var newstr = document.all.item(printpage).innerHTML;
var oldstr = document.body.innerHTML;
document.body.innerHTML = headstr+newstr+footstr;
window.print();
document.body.innerHTML = oldstr;
return false;
}
</script>
<?php
include("footer.php");
?>
