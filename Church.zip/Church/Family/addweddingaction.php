<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{   
    $FamilyId=$_SESSION['FamilyId'];
	$membergid=$_POST["Membermname"];
	$memberbid=$_POST["Memberfname"];
	$WeddingDate=$_POST['txt_wdate'];
	$OpponentParish=$_POST['txt_parish'];
	$OpponentDioces=$_POST['txt_dioces'];
	$OpponentFamilyname=$_POST['txt_ofname'];
	$WeddingPriest=$_POST['txt_priest'];
	$WeddingChurch=$_POST['txt_church'];
	$WeddingWitness1=$_POST['txt_wit1'];
	$WeddingWitness2=$_POST['txt_wit2'];
	
	
$sql=mysqli_query($con,"INSERT INTO tbl_wedding(Famid,BParish,BDiocese,WPriest,WChurch,BFamilyName,WDate,Groom,WW1,WW2,WStatus,Bride)VALUES('$FamilyId','$OpponentParish','$OpponentDioces','$WeddingPriest','$WeddingChurch','$OpponentFamilyname','$WeddingDate','$membergid','$WeddingWitness1','$WeddingWitness2','pending','$memberbid')");


if($sql)
  {
	 
echo "<script>alert('Wedding Details Registered Successfully!!');window.location='index.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='index.php'</script>";
  }


}
?>
