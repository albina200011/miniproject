<?php
include("header.php");
?><?php
include("config.php");
$sid=$_GET["sid"];
//echo $sid;
$sql=mysqli_query($con,"SELECT * FROM `tbl_certificaterequest` where CertRequestId='$sid'");

$display=mysqli_fetch_array($sql); 
$CertificatetypeId=$display['CType'];


// 1 is baptism in request mater
If($CertificatetypeId==1)
{
   
include("certificatebaptism.php");


}

// 2 is holy communion in request mater
If($CertificatetypeId==2)
{
include("holycommunioncertificate.php");
}
// 3 is wedding in request mater
If($CertificatetypeId==3)
{
include("weddingcertificate.php");
}

// 4 is death in request mater
If($CertificatetypeId==4)
{
include("deathcertificate.php");
}	
?>