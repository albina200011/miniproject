<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
include("config.php");
?>
<form action="actionmember.php" method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:93px; margin-bottom:10%;padding-left:130px; box-shadow: 2px 2px 10px #1b93e1; border-radius: 4px; top: 14px; margin-top: 3%;">
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">MEMBER REGISTRATION</h2>

 
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Member Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_mname" style="width:500px;" placeholder="Enter Your Name" pattern="^[A-Za_z][A-Za-z -]+$" required>
      </div>
    </div>
       <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label> Member Father Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_mfname" style="width:500px;" placeholder="Enter  Your Father Name" pattern="^[A-Za_z][A-Za-z -]+$"  required >
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Member Mother Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_mmname" style="width:500px;" placeholder="Enter Your Mother Name" pattern="^[A-Za_z][A-Za-z -]+$"  required>
      </div>
    </div>
   <br>
    <div class="row">
    
     <div class="col-md-3" style="text-align:left">
        <label>Email:</label>
      </div>
      <div class="col-md-6">
        <input type="email" class="form-control" name="txt_mail" style="width:500px;" title="please enter a valid email address" placeholder="Enter  Your Email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Gender:</label>
      </div>
      <div class="col-md-6">
      <input type="radio" name="rbgat" value="Male" checked/>Male
     <input type="radio" name="rbgat" value="Female"/>Female
     <input type="radio" name="rbgat" value="Others"/>Others
       
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Status:</label>
      </div>
      <div class="col-md-6">
      
      
      <select name="txt_status"  class="form-control" style="width:500px;" required>
	   <option value="">----------Select----------</option>
        <option value="Married">Married</option>
         <option value="Unmarried">Unmarried</option>
         </select>
      
       
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Date Of Birth:</label>
      </div>
      <div class="col-md-6">
        <input type="date" max="<?php echo date('Y-m-d') ?>" class="form-control" name="txt_mdob" style="width:500px;" placeholder="Enter  Your Date Of Birth"  required>
      </div>
    </div>
    <br>
   
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Relation With Head:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_rwh" style="width:500px;"  placeholder="Enter  Your Relation With Head" pattern="^[A-Za_z][A-Za-z -]+$"  required>
      </div>
    </div> 
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Baptism Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_bname" style="width:500px;" placeholder="Enter  Your Baptism Name"  pattern="^[A-Za_z][A-Za-z -]+$" required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Baptism Date:</label>
      </div>
      <div class="col-md-6">
  <input type="date"  max="<?php echo date('Y-m-d') ?>"  class="form-control" name="txt_bdate" style="width:500px;" placeholder="Enter  Your Baptism Name"  >
       <!--  <input type="radio" name="rbbdate" id="rbbdate" value="1" />Unknown Baptism Date
         
         <input type=button value="Uncheck" onclick="document.getElementById('rbbdate').checked = false" class="btn btn-danger">
      --></div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Baptism Priest:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_bpriest" style="width:500px;" placeholder="Enter  The Priest Name" pattern="^[A-Za_z][A-Za-z -]+$"   >
       
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Baptism Church:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_bchurch" style="width:500px;" placeholder="Enter  The Church Name" pattern="^[A-Za_z][A-Za-z -]+$"   >
         
     
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Baptism Details:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_bdetails" style="width:500px;" placeholder="Enter  Baptism Details"  pattern="^[A-Za_z][A-Za-z -]+$"  required>
        
     
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Contact Number:</label>
      </div>
      <div class="col-md-6">
        <input type="tel" class="form-control" name="txt_number" style="width:500px;" pattern="[0-9]{10}" title="Ten digits code" placeholder="Enter  Your Contact number" required pattern="[0-9]{10}">
      </div>
    </div>
    <br>
    <div class="row">
    
    <!-- <label style="color:red;">If you selected the UNKNOwN option in the datas,save the information as Unknown!!</label>-->
      <input type="submit" name="btnsubmit" value="Save" class="btn btn-primary" style="margin-left:63%">
    </div>
    <br>
     </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>
