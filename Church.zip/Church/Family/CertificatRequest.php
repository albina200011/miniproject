<?php
 session_start();
 $familyregno=$_SESSION["FamilyId"];
	?>
	<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<body>
<?php
include("config.php");
?>
<form action="addrequestaction.php" method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:93px; margin-bottom:10%;padding-left:130px; box-shadow: 2px 2px 10px #1b93e1; border-radius: 4px; top: 14px; margin-top: 3%;">
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">CERTIFICATE REQUEST</h2>

  <br>
     <div class="row">
     <div class="col-md-3" style="text-align:left">
        <?php
$familyregno=$_SESSION["FamilyId"];
$sql=mysqli_query($con,"select * from tbl_member WHERE FId=$familyregno"); 
?>
<label>Member Name</label><br>
 </div>
      <div class="col-md-6">
<select name="Membermname" onchange="showResult(this.value)"  class="form-control" >
<option value="0">--select--</option>
<?php
while($row=mysqli_fetch_array($sql))
{

?>
<option value="<?php echo $row[0] ?>" ><?php echo $row[1] ?></option>
<?php
	
}
?>

</select>
</div>
</div>
    <br>
    
     <div class="row">
     <div class="col-md-3" style="text-align:left">
        <?php
$familyregno=$_SESSION["FamilyId"];

$sql=mysqli_query($con,"select * from tbl_certificatemaster where CStatus=0"); 
?>
<label>Certificate Type</label><br>
 </div>
      <div class="col-md-6">
<select name="certificatename" onchange="showResult(this.value)"  class="form-control" >
<option value="0">--select--</option>
<?php
while($row=mysqli_fetch_array($sql))
{
?>
<option value="<?php echo $row[0] ?>" ><?php echo $row[1] ?></option>
<?php	
}
?>
</select>
</div>
</div>
       <br>
         <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Request Purpose:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_rpurpose" style="width:500px;" pattern="^[A-Za_z][A-Za-z -]+$" title="Must enter a  valid purpose" placeholder="Enter The Purpose" required>
      </div>
    </div> 
       <br>
          <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Required Date:</label>
      </div>
      <div class="col-md-6">
        <input type="Date" class="form-control" name="txt_rdate" style="width:500px;" min="<?php echo date('Y-m-d') ?>">
      </div>
    </div>
       <br>
     <div class="row">
      <input type="submit" name="btnsubmit" value="Save" class="btn btn-primary" style="margin-left:63%">
    </div>
    <br>
     </div>
     
</form>
</body>
</html>
<?php
include("footer.php");
?>
