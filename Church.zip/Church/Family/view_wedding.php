<?php
session_start();
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<body>
<form action="reg_wedding.php" method="post">
 <div class="container" style="width:200%;margin-left:13%;margin-bottom: 5%;" >
  
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
      <input type="submit" name="addnew" value="AddNew" class="btn btn-primary" style="margin-left:63%">
    </div>
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">WEDDING DETAILS</h2>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
   <th> SlNo</th>
    <th>Groom Name</th>
    <th>Bride Name</th>
    <th>Wedding Date</th>
    <th>Wedding Church</th>
    
 
    
    <?php
include("config.php");
?>
<?php
$s=1;

$familyregno=$_SESSION["FamilyId"];
//echo $familyregno;
$sql=mysqli_query($con,"SELECT w.*,m1.MemberNm as groom,m2.MemberNm as bride FROM tbl_wedding w inner join tbl_member m1 on m1.MemberId=w.Groom inner join tbl_member m2 on m2.MemberId=w.Bride WHERE m1.FId=$familyregno and WStatus='accepted'");

//echo "SELECT w.*,m1.MemberFname as groom,m2.MemberFname as bride FROM tbl_wedding w inner join tbl_member m1  on m1.MemberId=w.GroomId inner join tbl_member m2 on m2.MemberId=w.BrideId WHERE m1.FamilyId=$familyregno and WeddingStatus='accepted'";
   while($display=mysqli_fetch_array($sql))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	echo "<td>".$display["groom"]."</td>";
	
	echo "<td>".$display["bride"]."</td>";
	
	echo "<td>".$display["WDate"]."</td>";
	echo "<td>".$display["WChurch"]."</td>";
	
	echo "</tr>";
	
  }

echo "</table>";

?>
  </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>