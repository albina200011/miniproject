<?php
session_start();
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
include("config.php");
?>
<form action="HoliCommunion.php" method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:93px; margin-bottom:10%;padding-left:130px; box-shadow: 2px 2px 10px #1b93e1; border-radius: 4px; top: 14px; margin-top: 3%;">
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">HOLYCOMMUNION REGISTRATION</h2>

 
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Holycommunion Date:</label>
      </div>
      <div class="col-md-6">
        <input type="date" class="form-control"  max="<?php echo date('Y-m-d') ?>" name="txt_holydate" style="width:500px;" placeholder="Enter Holycommunion Date" >
      
      </div>
    </div>
       <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>MemberName:</label>
      </div>
      <div class="col-md-6">
       <?php
	   $_familtregno=$_SESSION["FamilyId"];

	   $sql=mysqli_query($con,"select * from tbl_member WHERE FId=$_familtregno and MemberStatus='1'");?>
	   <select name="drpMemberId"  class="form-control" style="width:500px;" required>
	   <option value="">----------Select----------</option>
	   <?php
	   while($row=mysqli_fetch_array($sql))
	   {
		   
		   ?>
		   
		   <option value="<?php echo $row['MemberId']?>"><?php echo $row['MemberNm'];?></option>
		   
           <?php
	   }
	   ?>
       </select>
       </div>
    </div>
    <br>
     <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Holycommunion Priest:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_holypriest" style="width:500px;" placeholder="Enter Holycommunion Priest" pattern="^[A-Za_z][A-Za-z -]+$" required>
      </div>
    </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Holycommunion Church:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_holychurch" style="width:500px;" placeholder="Enter Holycommunion church" pattern="^[A-Za_z][A-Za-z -]+$">
         
      </div>
    </div>
    <br>
     <div class="row">
    
      <input type="submit" name="btnsubmit" value="Save" class="btn btn-primary" style="margin-left:63%">
    </div>
    <br>
     </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>
