<?php

include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{
	$FamilyId=$_SESSION['FamilyId'];
	$MemberName=$_POST['txt_mname'];
	$MFName=$_POST['txt_mfname'];
	$MMName=$_POST['txt_mmname'];
    $Mail=$_POST['txt_mail'];
    $Gender=$_POST['rbgat'];
    $Status=$_POST['txt_status'];
    $Dob=$_POST['txt_mdob'];
    
    $RelationWHead=$_POST['txt_rwh'];
  
    $BName=$_POST['txt_bname'];
	
	
	$BDateStatus=$_POST['txt_bdate'];
	$BPriest=$_POST['txt_bpriest'];
	$BChurch=$_POST['txt_bchurch'];
	$BDetails=$_POST['txt_bdetails'];
		
	
	
    
    $BDate=$_POST['txt_bdate'];
   
	$ConNo=$_POST['txt_number'];
		
		
$sql=mysqli_query($con,"INSERT INTO tbl_member(MemberNm,MFName,MMName,MEmail,MGender,MStatus,MDob,FId,RWithHead,BName,BDate,BPriest,BChurch,BDetails,ConNo,MemberStatus) VALUES('$MemberName','$MFName','$MMName','$Mail','$Gender','$Status','$Dob','$FamilyId','$RelationWHead','$BName','$BDate','$BPriest','$BChurch','$BDetails','$ConNo','0')");


//echo "INSERT INTO tbl_member(MemberNm,MFName,MMName,MEmail,MGender,MStatus,MDob,FId,RWithHead,BName,BDate,BPriest,BChurch,BDetails,ConNo,MemberStatus,BDateStatus) VALUES('$MemberName','$MFName','$MMName','$Mail','$Gender','$Status','$Dob','$FamilyId','$RelationWHead','$BName','$BDate','$BPriest','$BChurch','$BDetails','$ConNo','0','$BDateStatus')";

if($sql)
  {
	 
echo "<script>alert('Member Details Registered Successfully!!');window.location='index.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='index.php'</script>";
  }
}

?>
