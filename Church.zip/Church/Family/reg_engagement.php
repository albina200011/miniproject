<?php
 session_start();
 $familyregno=$_SESSION["FamilyId"];
 
	?>
	<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
include("config.php");
?>
<form action="addengagementaction.php" method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:93px; margin-bottom:10%;padding-left:130px; box-shadow: 2px 2px 10px #1b93e1; border-radius: 4px; top: 14px; margin-top: 3%;">
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">BETROTHAL REGISTRATION</h2>

 
    <br>
    
     <div class="row">
     <div class="col-md-3" style="text-align:left">
        <?php
$con=mysqli_connect("localhost","root","","dbchurch");

$familyregno=$_SESSION["FamilyId"];

$sql=mysqli_query($con,"select * from tbl_member WHERE FId=$familyregno"); 
?>
<label>Name</label><br>
 </div>
      <div class="col-md-6">
<select name="MemberName" onchange="showResult(this.value)"  class="form-control" required >
<option value="">--select--</option>
<?php
while($row=mysqli_fetch_array($sql))
{

?>
<option value="<?php echo $row[0] ?>" ><?php echo $row[1] ?></option>
<?php
	
}
?>

</select>
</div>
</div>

    <br>
  <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Partner's Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_pname" style="width:500px;" pattern="^[A-Za_z][A-Za-z -]+$" title="Must enter a  valid name" placeholder="Enter Partner's Name" required>
      </div>
    </div>
       <br>
       <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Engagement Date:</label>
      </div>
      <div class="col-md-6">
        <input type="date" class="form-control" name="txt_edate" style="width:500px;" required  max="<?php echo date('Y-m-d') ?>">
      </div>
    </div>
       <br>
         <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Name of Father:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_fname" style="width:500px;" pattern="^[A-Za_z][A-Za-z -]+$" title="Must enter a  valid partner's name" placeholder="Enter Partner's Father Name" required>
      </div>
    </div>
       <br>
        
         <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Name of Mother:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_mname" style="width:500px;" pattern="^[A-Za_z][A-Za-z -]+$" title="Must enter a  valid name" placeholder="Enter Partner's Mother Name" required>
      </div>
    </div>
       <br>
        <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Baptism Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_bname" style="width:500px;" pattern="^[A-Za_z][A-Za-z -]+$" title="Must enter a  valid name" placeholder="Enter Partner's Baptism Name" required>
      </div>
    </div>
       <br>
        <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Priest:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_priest" style="width:500px;" pattern="^[A-Za_z][A-Za-z -]+$" title="Must enter a  valid name" placeholder="Enter Priest Name" required>
      </div>
    </div>
       <br>
         <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Engagement Church:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_church" style="width:500px;" pattern="^[A-Za_z][A-Za-z -]+$" title="Must enter a  valid name" placeholder="Enter Church Name" required>
      </div>
    </div>
    <br>
         <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Engagement Witness:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_ewitness" style="width:500px;" pattern="^[A-Za_z][A-Za-z -]+$" title="Must enter a  valid name" placeholder="Enter Witness Name" required>
      </div>
    </div>
       <br>
        
     <div class="row">
      <input type="submit" name="btnsubmit" value="Save" class="btn btn-primary" style="margin-left:63%">
    </div>
    <br>
     </div>
     
</form>
</body>
</html>
<?php
include("footer.php");
?>
