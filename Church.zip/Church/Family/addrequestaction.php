<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{
	$memberid=$_POST["Membermname"];
	$certtype=$_POST['certificatename'];
	$purpose=$_POST['txt_rpurpose'];
	$date=$_POST['txt_rdate'];
	
	
	
$sql=mysqli_query($con,"INSERT INTO tbl_certificaterequest(CMId,CType,RequestPurpose,RequriedDate,CertStatus)VALUES('$memberid','$certtype','$purpose','$date','pending')");


if($sql)
  {
	 
echo "<script>alert('Request Details Registered Successfully!!');window.location='index.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='index.php'</script>";
  }


}
?>
