<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>

<form action="" method="post">
  <div class="container" style="width:100%;margin-left:13%;margin-bottom: 5%;" >
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
  
  </div>
  
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">APPROVED CERTIFICATE DETAILS</h2>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
  
  
   
     

   
   <?php

include("config.php");

if(isset($_GET["crId"]))

{
	$CRId=$_GET["crId"];
	
	   
	$sql=mysqli_query($con,"SELECT cr.*,m1.MemberNm as CMId,m2.CertificateType as CType FROM tbl_certificaterequest cr inner join tbl_member m1  on m1.MemberId=cr.CMId inner join tbl_Certificatemaster m2 on m2.CertificateId=cr.CType WHERE CertRequestId='$CRId'");



   
    

   
   while($display=mysqli_fetch_array($sql))
   {
	echo "<tr>";

	echo "<td>Name :</td>";
	echo "<td>".$display["CMId"]."</td>";

	echo "</tr>";
	echo "<tr>";
	echo "<td>Certificate Type :</td>";
    echo "<td>".$display["CType"]."</td>";
	echo "</tr>";
  
	echo "<tr>";
	echo "<td>Request Purpose  :</td>";
    echo "<td>".$display["RequestPurpose"]."</td>";
	echo "</tr>";
    
    echo "<tr>";
	echo "<td>Requried Date :</td>";
    echo "<td>".$display["RequriedDate"]."</td>";
	echo "</tr>";
    
	
	
   }
   
}

echo "</table>";

?>


   <br> 
    
  </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>

<?php
include("footer.php");
?>