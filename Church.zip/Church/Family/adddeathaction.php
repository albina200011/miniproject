<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{
	$memberid=$_POST["Membermname"];
	$deathdate=$_POST['txt_ddate'];
	$funeraldate=$_POST['txt_fdate'];
	$priest=$_POST['txt_priest'];
	$church=$_POST['txt_church'];
	$comment=$_POST['txt_comment'];
	
	
$sql=mysqli_query($con,"INSERT INTO tbl_death(DeathDate,DeathFdate,DPriest,DChurch,Comment,DeathStatus,DMId)VALUES('$deathdate','$funeraldate','$priest','$church','$comment','pending','$memberid')");


if($sql)
  {
	 
echo "<script>alert('Death Details Registered Successfully!!');window.location='index.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='index.php'</script>";
  }


}
?>
