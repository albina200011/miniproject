<?php
include("config.php");
session_start();
if(isset($_POST["btnsubmit"]))
{
	$memberid=$_POST["MemberName"];
	$engagementpname=$_POST['txt_pname'];
	$engagementdate=$_POST['txt_edate'];
	$engagementfname=$_POST['txt_fname'];
	$engagementmname=$_POST['txt_mname'];
	$engagementbname=$_POST['txt_bname'];
	$engagementpriest=$_POST['txt_priest'];
	$engagementchurch=$_POST['txt_church'];
	$engagementwitness=$_POST['txt_ewitness'];
	
	
$sql=mysqli_query($con,"INSERT INTO tbl_engagement(EngMID,EngPN,EngDate,EngPFN,EngPMN,EngPBN,EngPriest,EngChurch,EngWitness,EngStatus)VALUES('$memberid','$engagementpname','$engagementdate','$engagementfname','$engagementmname','$engagementbname','$engagementpriest','$engagementchurch','$engagementwitness','Pending')");


if($sql)
  {
	 
echo "<script>alert('Betrothal Details Registered Successfully!!');window.location='index.php'</script>";
  }
else
  {
echo "<script>alert('Error');window.location='index.php'</script>";
  }


}
?>
