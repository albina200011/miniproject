<?php
include("header.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<!-- ##### Hero Area Start ##### -->
    <section class="hero-area">
        <div class="hero-slides owl-carousel">
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img bg-overlay" style="background-image: url(img/bg-img/bg-2.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">
                        <div class="col-12 col-lg-7">
                            <!-- Slides Content -->
                            <div class="hero-slides-content">
                                <h6 class="date" data-animation="fadeInUp" data-delay="100ms">July 2020</h6>
                                <h3 data-animation="fadeInUp" data-delay="300ms">Let God guide your path</h3>
                                <h2 data-animation="fadeInUp" data-delay="500ms">Children Camp</h2>
                                <p data-animation="fadeInUp" data-delay="700ms">Jesus said,"Let the little children come to me,and do not hinder them,for the kindom of heaven belongs to such as these." [MATHEW 19:14]</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Event Button -->
                <div class="next-event-btn" data-animation="bounceInDown" data-delay="900ms">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 text-right">
                                <a href="#" class="btn faith-btn active">Sunday Workship: 10:30 AM</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img bg-overlay" style="background-image: url(img/bg-img/bg-1.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">
                        <div class="col-12 col-lg-7">
                            <!-- Slides Content -->
                            <div class="hero-slides-content">
                                <h6 class="date" data-animation="fadeInUp" data-delay="100ms">July 2020</h6>
                                <h3 data-animation="fadeInUp" data-delay="300ms">Let God guide your path</h3>
                                <h2 data-animation="fadeInUp" data-delay="500ms">Children Camp</h2>
                                <p data-animation="fadeInUp" data-delay="700ms">Jesus said,"Let the little children come to me,and do not hinder them,for the kindom of heaven belongs to such as these." [MATHEW 19:14]</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Event Button -->
                <div class="next-event-btn" data-animation="bounceInDown" data-delay="900ms">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 text-right">
                                <a href="#" class="btn faith-btn active">Sunday Workship: 10:30 AM</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img bg-overlay" style="background-image: url(img/bg-img/bg-3.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12 col-lg-7">
                            <!-- Slides Content -->
                            <div class="hero-slides-content">
                                <h6 class="date" data-animation="fadeInUp" data-delay="100ms">July 2020</h6>
                                <h3 data-animation="fadeInUp" data-delay="300ms">Let God guide your path</h3>
                                <h2 data-animation="fadeInUp" data-delay="500ms">Children Camp</h2>
                                <p data-animation="fadeInUp" data-delay="700ms">Jesus said,"Let the little children come to me,and do not hinder them,for the kindom of heaven belongs to such as these." [MATHEW 19:14]</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Event Button -->
                <div class="next-event-btn" data-animation="bounceInDown" data-delay="900ms">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 text-right">
                                <a href="#" class="btn faith-btn active">Sunday Workship: 10:30 AM</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Hero Area End ##### -->

    <!-- ##### CTA Area Start ##### -->
    <div class="faith-cta-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="cta-text d-flex justify-content-between align-items-center">
                        <h5> I  can  do  everthing  through  christ, who  gives  me  strength. [PHILIPPIANS 4:13]</h5>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### CTA Area End ##### -->

    <!-- ##### About Area Start ##### -->
    <section class="faith-about-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="about-content">
                        <img src="img/core-img/holy-star.png" alt="">
                        <h2>“Blessed is the one who takes refuge <br>in him.”</h2>
                        <h6>When life lets you down, hold on to God’s promises. Our Greatest blessing, in any situation whether good or bad, is being able to experience the Lord and His goodness in our lives. Therefore, we take refuge in Him knowing that He will be faithful to fulfill all of His promises in Christ Jesus, our Lord. God Bless and have a great day in God’s Word.</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### About Area End ##### -->

    <!-- ##### Church Activities Area Start ##### -->
    <section class="church-activities-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto">
                        <img src="img/core-img/cross.png" alt="">
                        <h3>Church Activities</h3>
                        
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-lg-6">
                    <!-- Upcoming Events -->
                    <div class="upcoming-events mb-100">
                        <!-- Headline -->
                        <div class="headline">
                            <h5>Upcoming Events</h5>
                        </div>

                        <!-- Single Upcoming Events -->
                        <div class="single-upcoming-events d-flex align-items-center">
                            <!-- Events Date & Thumbnail -->
                            <div class="event-date-thumbnail d-flex align-items-center">
                                <div class="event-date">
                                    <h6>03 <br> Jun <br> 2020</h6>
                                </div>
                                <div class="event-thumbnail bg-img" style="background-image: url(img/bg-img/event1.jpg);"></div>
                            </div>
                            <!-- Events Content -->
                            <div class="events-content">
                                <a href="#">
                                    <h6>Weekend Bible Study with believers</h6>
                                </a>
                                <p>8:00 pm @ Main hall</p>
                            </div>
                        </div>

                        <!-- Single Upcoming Events -->
                        <div class="single-upcoming-events d-flex align-items-center">
                            <!-- Events Date & Thumbnail -->
                            <div class="event-date-thumbnail d-flex align-items-center">
                                <div class="event-date">
                                    <h6>09 <br> Jun <br> 2020</h6>
                                </div>
                                <div class="event-thumbnail bg-img" style="background-image: url(img/bg-img/event2.jpg);"></div>
                            </div>
                            <!-- Events Content -->
                            <div class="events-content">
                                <a href="#">
                                    <h6>Bible Study for Childrens</h6>
                                </a>
                                <p>8:00 pm @ Main hall</p>
                            </div>
                        </div>

                        <!-- Single Upcoming Events -->
                        <div class="single-upcoming-events d-flex align-items-center">
                            <!-- Events Date & Thumbnail -->
                            <div class="event-date-thumbnail d-flex align-items-center">
                                <div class="event-date">
                                    <h6>11 <br> Jun <br> 2020</h6>
                                </div>
                                <div class="event-thumbnail bg-img" style="background-image: url(img/bg-img/event3.jpg);"></div>
                            </div>
                            <!-- Events Content -->
                            <div class="events-content">
                                <a href="#">
                                    <h6>Weekend Bible Study with believers</h6>
                                </a>
                                <p>8:00 pm @ Main hall</p>
                            </div>
                        </div>

                        <!-- Single Upcoming Events -->
                        <div class="single-upcoming-events d-flex align-items-center">
                            <!-- Events Date & Thumbnail -->
                            <div class="event-date-thumbnail d-flex align-items-center">
                                <div class="event-date">
                                    <h6>25 <br> Jun <br> 2020</h6>
                                </div>
                                <div class="event-thumbnail bg-img" style="background-image: url(img/bg-img/event4.jpg);"></div>
                            </div>
                            <!-- Events Content -->
                            <div class="events-content">
                                <a href="#">
                                    <h6>Bible Study for Childrens</h6>
                                </a>
                                <p>8:00 pm @ Main hall</p>
                            </div>
                        </div>

                        <div class="all-events-btn">
                            <a href="#" class="btn faith-btn active">See All Events</a>
                        </div>

                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <!-- Latest Sermons -->
                    <div class="latest-sermons mb-100">
                        <div class="headline">
                            <h5>Latest Sermons</h5>
                        </div>

                        <!-- Single Sermons Area -->
                        <div class="single-sermons">
                            <div class="sermons-content d-flex align-items-center">
                                <!-- Sermons Thumbnail -->
                                <div class="sermons-thumbnail bg-img" style="background-image: url(img/bg-img/ser1.jpg);"></div>
                                <!-- Sermons Content -->
                                <div class="sermons-text">
                                    <a href="#">
                                        <h6>Weekend Bible Study with believers</h6>
                                    </a>
                                    <p>By Priest Michael Smith</p>
                                    <p class="date">02 April, 2020</p>
                                </div>
                            </div>
                            <div class="sermons-audio-player d-flex align-items-center">
                                
                                <div class="see-more-btn">
                                    <a href="#">See More</a>
                                </div>
                            </div>
                        </div>

                        <!-- Single Sermons Area -->
                        <div class="single-sermons">
                            <div class="sermons-content d-flex align-items-center">
                                <!-- Sermons Thumbnail -->
                                <div class="sermons-thumbnail bg-img" style="background-image: url(img/bg-img/ser2.jpg);"></div>
                                <!-- Sermons Content -->
                                <div class="sermons-text">
                                    <a href="#">
                                        <h6>Weekend Bible Study with believers</h6>
                                    </a>
                                    <p>By Priest Michael Smith</p>
                                    <p class="date">02 April, 2020</p>
                                </div>
                            </div>
                            <div class="sermons-audio-player d-flex align-items-center">
                               
                                <div class="see-more-btn">
                                    <a href="#">See More</a>
                                </div>
                            </div>
                        </div>

                        <!-- Single Sermons Area -->
                        <div class="single-sermons">
                            <div class="sermons-content d-flex align-items-center">
                                <!-- Sermons Thumbnail -->
                                <div class="sermons-thumbnail bg-img" style="background-image: url(img/bg-img/ser3.jpg);"></div>
                                <!-- Sermons Content -->
                                <div class="sermons-text">
                                    <a href="#">
                                        <h6>Weekend Bible Study with believers</h6>
                                    </a>
                                    <p>By Priest Michael Smith</p>
                                    <p class="date">02 April, 2020</p>
                                </div>
                            </div>
                            <div class="sermons-audio-player d-flex align-items-center">
                               
                                <div class="see-more-btn">
                                    <a href="#">See More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   
</body>
</html>
<?php
include("footer.php");
?>