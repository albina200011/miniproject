<?php
session_start();
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<form action="reg_certificaterequest.php" method="post">
  <div class="container" style="width:100%;margin-left:13%;margin-bottom: 5%;" >
  
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
     
    </div>
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">APPROVED CERTIFICATE DETAILS</h2>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
  
    <th> SlNo</th>
     <th>Member Name</th>
     <th>Certificate Type</th>
   <th style="color:#F00">View More</th>
  <th style="color:#F00">Print Certificate</th>
  
 
    <?php
include("config.php");
$s=1;
$fid=$_SESSION["FamilyId"];
$sql=mysqli_query($con,"SELECT cr.*,m1.MemberNm as CMId,m2.CertificateType as CType,FId  FROM tbl_certificaterequest cr inner join tbl_member m1  on m1.MemberId=cr.CMId inner join tbl_Certificatemaster m2 on m2.CertificateId=cr.CType WHERE  cr.CertStatus='accepted' and FId='$fid'");


while($display=mysqli_fetch_array($sql))
  {
	  echo "<tr>";

   echo"<td>".$s++."</td>";
   echo "<td>".$display["CMId"]."</td>";
    echo "<td>".$display["CType"]."</td>";
   
   echo "<td><a style='color:#090' href='viewmorereq.php?crId=".$display['CertRequestId']."'>View More</a> </td>";
   
 echo "<td><a style='color:#090' href='approvecertificate.php?sid=".$display['CertRequestId']."'>Print</a> </td>";
	
  echo "</tr>";
	}
echo "</table>";

?>
  </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>