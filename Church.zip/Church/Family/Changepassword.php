<?php
include("header.php");
session_start();
?> 
<!DOCTYPE html>
<html>
<head>
<title>Untitled Document</title>
</head>
<body>
<?php
include("config.php");
	$FamilyId=$_SESSION['FamilyId'];
	$sql=mysqli_query($con,"SELECT * FROM `tbl_family` where FamilyId='$FamilyId'");
	$display=mysqli_fetch_array($sql);
	$curentpwd=$display["Pwd"];

?>
<form action="" method="POST"> 
<div class="container" style="width:100%;margin-left:18%;margin-bottom: 5%;padding-top:10%" >

  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
  </div>
<h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">CHANGE YOUR PASSWORD</h2>
  <br>
   <div class="row">
     <div class="col-md-3" style="text-align:right">
        <label>Current Password</label>
      </div>
      <div class="col-md-6">
        <input type="password" class="form-control" placeholder="Enter Current Password" name="txt_curpassword" style="width:500px;" >
      </div>
      </div>
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:right">
        <label>Enter New Password</label>
      </div>
      <div class="col-md-6">
        <input type="password" class="form-control" name="txt_newpassword" style="width:500px;" placeholder="Enter New Password"  required >
      </div>
      </div>

   <br>
     <div class="row">
      <input type="submit" name="btnsubmit" value="Reset" class="btn btn-primary" style="margin-left:63%">
    </div>
</div>
</div>
</div>
</div>
</form>
</body>
</html>
<?php
if(isset($_POST["btnsubmit"]))
{
	$enterpassword=$_POST['txt_curpassword'];
echo	$curentpwd;
echo $enterpassword;
	if($curentpwd==$enterpassword)
	{
		
		
	
			$password=$_POST['txt_newpassword'];
			$sql=mysqli_query($con,"UPDATE tbl_family SET Pwd='$password' WHERE FamilyId='$FamilyId'");
			if($sql)
			{
					echo "<script>alert('Password Updated Succesfully!!Plase login again!!');window.location='../Guest/index.php'</script>";
			}
	}
	else
		echo "<script>alert('Please enter current password correctlty!!');window.location='Changepassword.php'</script>";
}
?>
<?php
include("footer.php");
?>