<?php
session_start();
include("header.php");

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<form action="memberreg.php" method="post">
 <div class="container" style="width:200%;margin-left:4%;margin-bottom: 5%;" >
  
  <div class="row">
  <div class="col-md-12" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
      <input type="submit" name="addnew" value="AddNew" class="btn btn-primary" style="margin-left:63%">
      </div>
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
      </div>
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">MEMBER DETAILS</h2>
<div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">

    <th> SlNo</th>
    <th>Member  Name</th>
    <th>Member Gender</th>
    <th>Member Contact</th>
    <th>Member Email</th>
    <th>Baptism Name</th>
    <th>Baptism Date</th>
    <th>Relation Head</th>
    <th>DOB</th>
   
    
    <!--<th style="color:#F00">Edit</th>
    <th style="color:#F00">Delete</th>-->
    <?php
include("config.php");
$s=1;
$_familtregno=$_SESSION["FamilyId"];

$sql=mysqli_query($con,"SELECT * FROM tbl_member WHERE FId=$_familtregno and MemberStatus='1'");
//echo "SELECT * FROM tbl_member WHERE FamilyId=$_familtregno and MemberStatus='accepted'";
   while($display=mysqli_fetch_array($sql))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	echo "<td>".$display["MemberNm"]."</td>";
	echo "<td>".$display["MGender"]."</td>";
	echo "<td>".$display["ConNo"]."</td>";
	echo "<td>".$display["MEmail"]."</td>";
	echo "<td>".$display["BName"]."</td>";
	echo "<td>".$display["BDate"]."</td>";
	echo "<td>".$display["RWithHead"]."</td>";
	echo "<td>".$display["MDob"]."</td>";
	/*echo "<td><a style='color:#090' href='edit_member.php?MemberId=".$display['MemberId']."'>Edit</a> </td>";
	echo "<td><a style='color:#090' href='deletemember.php?MemberId=".$display['MemberId']."'>Delete</a> </td>";*/
	echo "</tr>";
	
  }
echo "</table>";

?>
  </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>