<?php
session_start();
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<body>
<form action="reg_engagement.php" method="post">
 <div class="container" style="width:200%;margin-left:13%;margin-bottom: 5%;" >
  
  <div class="row">
  <div class="col-md-9" style="box-shadow: 2px 2px 10px #1b93e1; border-radius:0px; top: 14px;">
  <div class="row" style="margin-left: -173%;margin-top: 2%;margin-bottom: -5%;">
      <input type="submit" name="addnew" value="AddNew" class="btn btn-primary" style="margin-left:63%">
    </div>
  <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">ENGAGEMENT DETAILS</h2>
  <div class="form-horizontal" style="margin-left:0px;">
  <table class="table table-hover" style="border: 2px solid #adaaaa; box-shadow: 3px 3px 11px #777777; margin-bottom:7%">
   <th> SlNo</th>
    <th>Name</th>
    <th>Partner Name</th>
    <th>Engagement Date</th>
    <th>Engagement Church</th>
    <?php
include("config.php");
?>
<?php
$s=1;

$familyregno=$_SESSION["FamilyId"];
//echo $familyregno;
$sql=mysqli_query($con,"SELECT * FROM tbl_engagement e inner join tbl_member m on e.EngMID=m.MemberId WHERE m.FId=$familyregno and EngStatus='accepted'");
//echo "SELECT * FROM tbl_engagement e inner join tbl_member m on e.MemberId=m.MemberId WHERE m.FamilyId=$familyregno and EngagementStatus='accepted'";
   while($display=mysqli_fetch_array($sql))
   {
	echo "<tr>";
	echo"<td>".$s++."</td>";
	echo "<td>".$display["MemberNm"]."</td>";
	echo "<td>".$display["EngPN"]."</td>";
	
	echo "<td>".$display["EngDate"]."</td>";
	echo "<td>".$display["EngChurch"]."</td>";
	
	echo "</tr>";
	
  
}
echo "</table>";

?>
  </div>
  </div>
  <div> </div>
  </div>
  </div>
</form>
</body>
</html>
<?php
include("footer.php");
?>