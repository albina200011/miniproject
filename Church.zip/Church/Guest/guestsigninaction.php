<?php
include("config.php");
if(isset($_POST["btnsubmit"]))
{
	$UserName=$_POST['txt_username'];
	$Password=$_POST['txt_password'];
		$result=mysqli_query($con,"SELECT * from tbl_admin where Username='$UserName' and Password='$Password'");
  		$row=mysqli_fetch_array($result);
  		if($row>0)
		{
            header("location:../Admin/index.php");
        }
        else
        {
            
		echo "<script>alert('Invalid Username/Password!!');window.location='vicarlogin.php'</script>";	
		}
		
}
?>
