
<?php
session_start();
include("config.php");
if(isset($_POST["btnsubmit"]))
{
	$UserName=$_POST['txt_uname'];
	$Password=$_POST['txt_pwd'];
		$result=mysqli_query($con,"SELECT * from tbl_family where UserName='$UserName' and Pwd='$Password'");
  		$row=mysqli_fetch_array($result);
  		if($row>0)
		{
			$_SESSION["FamilyId"]=$row["FamilyId"];
            header("location:../Family/index.php");
        }
        else
        {
            
		echo "<script>alert('Invalid Username/Password!!');window.location='familylogin.php'</script>";	
		}
		
}
?>
