<?php
include("header.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
include("config.php");
?>
<form action="guestsigninaction.php" method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:93px; margin-bottom:10%;padding-left:130px; box-shadow: 2px 2px 10px #1b93e1; border-radius: 4px; top: 14px; margin-top: 3%;">
        <h2 style="text-align: center;margin-top: 6%;font-family: fantasy;">ADMIN LOGIN</h2>

 
    <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>User Name:</label>
      </div>
      <div class="col-md-6">
        <input type="text" class="form-control" name="txt_username" style="width:500px;" placeholder="Username" required>
      </div>
    </div>
       <br>
    <div class="row">
     <div class="col-md-3" style="text-align:left">
        <label>Password:</label>
      </div>
      <div class="col-md-6">
        <input type="password" class="form-control" name="txt_password" style="width:500px;" placeholder="Password" required autofocus>
      </div>
    </div>
    <br>
    <div class="row">
      <input type="submit" name="btnsubmit" value="Login" class="btn btn-primary" style="margin-left:63%">
    </div>
    <br>
     </div>
     
</form>
</body>
</html>
<?php
include("footer.php");
?>
